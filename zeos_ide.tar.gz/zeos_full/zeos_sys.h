#include <sched.h>

int zeos_fork(struct task_struct **child);

void zeos_exit();
